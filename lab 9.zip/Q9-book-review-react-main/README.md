# Books Review

## Installation

Install vite-project with npm

```bash
  cd Q9-book-review-react
  npm install
  npm run dev
```
