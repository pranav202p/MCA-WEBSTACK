var fs=require('fs')
const path = require("path");

fs.writeFile(path.join(__dirname,'posts','blog.txt'),'Pranav',function(err){
    if(err){
        console.log("Erorr----")
    }
    console.log("Data created sucessfully -----")
})