var fs=require('fs')
const path = require('path');

fs.unlink(path.join(__dirname,'posts','blog.txt'),function(err){
    if(err){
        console.log("Could not delete the data")
    }
    console.log("Deleted")
})