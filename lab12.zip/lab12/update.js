var fs=require('fs')
const path = require('path');

fs.writeFileSync(path.join(__dirname,'posts','blog.txt'),'2347137',function(err){
    if(err){
        console.log("Could not update the data")
    }
    console.log("Data updated")
})