var fs=require('fs')
const path = require('path');

fs.readFile(path.join(__dirname,'posts','blog.txt'),function(err,data){
    if(err){
        console.log("No file found")
    }
    console.log("Data read sucessfully")
    const content = Buffer.from(data);
    console.log(content.toString());
    

})